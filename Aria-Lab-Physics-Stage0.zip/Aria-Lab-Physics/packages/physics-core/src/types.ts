export type PhysicsDomain =
  | 'core'
  | 'mechanics'
  | 'circuits'
  | 'optics'
  | 'waves'
  | 'thermal'
  | 'fields'
  | 'fluids'
  | 'atomic'
  | 'presentation';

export interface QuantityValue {
  value: number;
  unit: string;
}

export interface PartProperty {
  key: string;
  kind: 'number' | 'integer' | 'boolean' | 'string' | 'enum' | 'vector2' | 'vector3' | 'color';
  quantity?: string;
  unit?: string;
  default?: unknown;
  min?: number;
  max?: number;
  step?: number;
  editable?: boolean;
  observable?: boolean;
}

export interface PartDefinition {
  id: string;
  name: string;
  nameFa?: string;
  domain: PhysicsDomain;
  category?: string;
  version: number;
  properties: PartProperty[];
}
